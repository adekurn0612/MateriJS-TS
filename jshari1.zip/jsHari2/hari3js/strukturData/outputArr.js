const outputArr=()=>{
    let arrStr=['Java','Script'];
    return arrStr
}

console.log(outputArr());
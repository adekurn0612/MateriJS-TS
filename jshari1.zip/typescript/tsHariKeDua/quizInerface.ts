// 

// interface summary{
//     getTotalVehicle();
//     getTotalVehicle(vehicleType:string);
//     getTotalIncome();
//     getTotalIncome(vehicleType:string);
// }
// abstract class vehicle{
//     constructor(vehicleType){
        
//         public 
//     }
// }
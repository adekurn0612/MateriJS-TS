{enum month {
    jan =1
}

console.log(month[1]);
}
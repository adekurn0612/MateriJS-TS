{
    var price = void 0;
    price = 9.95;
}

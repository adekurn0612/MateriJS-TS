let employee : object ;

let person : {} = {} ; //type objek untuk any
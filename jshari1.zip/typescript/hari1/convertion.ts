let number = '20';
console.log((typeof number));
let z = +number;
console.log(typeof z);

let stringBool = 'false';
console.log(typeof stringBool);
let newStringBool = Boolean(stringBool);
console.log(typeof newStringBool);
console.log(newStringBool);

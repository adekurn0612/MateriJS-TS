{let color : [number , number , number]= [255 , 0 ,0];
    console.log(color);
}
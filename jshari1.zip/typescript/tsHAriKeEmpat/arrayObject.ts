// let bilanganGenap: Object[] = [
// {id : 1,
// value : 2},
// {id : 2,
// value : 4},
// {id : 3,
// value : 6},
// {id : 4,
// value : 8},
// {id : 5,
// value : 10}
// ]

let bilanganGenapOtomatis:Object[]=[]

 for(let i  = 0; i <= 5; i++){
    bilanganGenapOtomatis.push({id : i, value:  i*2})
 }
 console.log(bilanganGenapOtomatis);
// let arr:number[]=[1234]
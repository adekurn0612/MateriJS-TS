import { Router } from "express";
import userController from "../controller/userController.js";
import productController from "../controller/productController.js";

const router=Router()

router.get("/", (req,res)=>{
    res.send(`selamat belajar backend`)
})

// router.get("/user",(req,res)=>{
//     res.send(`menampilkan data user`)
// })

router.post("/user", userController.CreateUser);
router.get("/user" , userController.findAllRows);
router.put("/user", userController.updateRows);
router.delete("/user", userController.DeleteAllrows);
router.post("/productcategory", productController.createProductCategory);
router.post("/product", productController.createProduct);

export default router;
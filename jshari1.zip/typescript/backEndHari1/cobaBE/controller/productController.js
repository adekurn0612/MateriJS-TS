import models from "../models/init-models.js"
import productcategory from "../models/productcategory.js"
import product from "../models/product.js"
import multer from "multer"

  
  


const createProductCategory = async (req , res) =>{
    try{
        const result = await models.productcategory.create({
            name : req.body.productCategoryName,
            description : req.body.description
        })
        res.status(202).send(result)
    }catch(e){
        res.status(400).send(e)
    }
  }

  const createProduct = async(req, res) => {
    try{
        const storage = multer.diskStorage({
            destination: function (req, file, cb) {
              cb(null, '/tmp/my-uploads')
            },
            filename: function (req, file, cb) {
              const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9)
              cb(null, file.fieldname + '-' + uniqueSuffix)
            }
          })
        const result = await models.product.create({
            name : req.body.producName,
            description : req.body.description,
            categoryid : req.body.categoryid,
            image : storage.filename,
            price : req.body.price
        })
        res.status(202).send(result)
    }catch(e){
        res.status(400).send(e)
    }
  }

  const upload = multer({ storage: storage })


  export default{
    createProductCategory,
    createProduct
  };